<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<html>
<head><title>Account Details</title></head>
<body>
    <h2>Account Details</h2>
    <p>Account Number: ${account.accountNumber}</p>
    <p>Balance: ${account.balance}</p>
    <!-- Add options for deposit, withdrawal, etc. -->
</body>
</html>
