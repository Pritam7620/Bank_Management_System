package com.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddCustomerServlet")
public class AddCustomerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String accountNumber = request.getParameter("account_number");
        String email = request.getParameter("email");
        String passwords = request.getParameter("passwords");
        String balanceStr = request.getParameter("balance");
        float balance = Float.parseFloat(balanceStr);

        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/banks", "root", "1972");

            String sql = "INSERT INTO bankdatabases(Name, account_number, email, passwords, balance) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, accountNumber);
            ps.setString(3, email);
            ps.setString(4, passwords);
            ps.setFloat(5, balance);

            String passwords1 = request.getParameter("passwords");
            String confirmPassword = request.getParameter("confirm_password");

            if (!passwords1.equals(confirmPassword)) {
                response.setContentType("text/html");
                response.getWriter().println("<script type=\"text/javascript\">");
                response.getWriter().println("alert('Passwords do not match. Please try again.');");
                response.getWriter().println("location='addCustomer.jsp';");
                response.getWriter().println("</script>");
                return;
            }

            
            ps.executeUpdate();
            ps.close();
            conn.close();

            response.sendRedirect("Welcome.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
