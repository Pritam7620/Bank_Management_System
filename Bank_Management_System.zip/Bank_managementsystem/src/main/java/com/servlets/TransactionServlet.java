package com.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/TransactionServlet")
public class TransactionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fromAcc = request.getParameter("fromAccount");
        String toAcc = request.getParameter("toAccount");
        float amount = Float.parseFloat(request.getParameter("amount"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/banks", "root", "1972");

            conn.setAutoCommit(false);

            
            PreparedStatement checkStmt = conn.prepareStatement("SELECT balance FROM bankdatabases WHERE account_number = ?");
            checkStmt.setString(1, fromAcc);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getFloat("balance") >= amount) {
               
                PreparedStatement deduct = conn.prepareStatement("UPDATE bankdatabases SET balance = balance - ? WHERE account_number = ?");
                deduct.setFloat(1, amount);
                deduct.setString(2, fromAcc);
                deduct.executeUpdate();

                
                PreparedStatement add = conn.prepareStatement("UPDATE bankdatabases SET balance = balance + ? WHERE account_number = ?");
                add.setFloat(1, amount);
                add.setString(2, toAcc);
                add.executeUpdate();

                conn.commit();
                response.sendRedirect("transactionSuccess.jsp");

            } else {
                conn.rollback();
                response.getWriter().println("Insufficient balance or invalid account.");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Transaction failed: " + e.getMessage());
        }
    }
}
